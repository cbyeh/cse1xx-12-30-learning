TO COMPILE THE JAVA FILE

javac *.java

TO RUN
java -Djava.util.loggin.config.file=logging.properties L1

java -Djava.util.loggin.config.file=otherlogging.properties L1

loop.sh can be run like any other shell script.
